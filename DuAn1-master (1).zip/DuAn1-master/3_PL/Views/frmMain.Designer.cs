﻿namespace _3_PL.Views
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            panel1 = new Panel();
            btnCaiDat = new Button();
            pictureBox1 = new PictureBox();
            btnThongKe = new Button();
            btnDanhMuc = new Button();
            btnKhachHang = new Button();
            btnHoaDon = new Button();
            btnDonHang = new Button();
            btnSanPham = new Button();
            panel2 = new Panel();
            label5 = new Label();
            label1 = new Label();
            lblUserName = new Label();
            panel3 = new Panel();
            pnContent = new Panel();
            rjDropdownMenu1 = new Helpers.RJDropdownMenu(components);
            kieuDanhMucToolStripMenuItem = new ToolStripMenuItem();
            danhMucToolStripMenuItem = new ToolStripMenuItem();
            loaiGiayToolStripMenuItem = new ToolStripMenuItem();
            sizeGiayToolStripMenuItem = new ToolStripMenuItem();
            chatLieuToolStripMenuItem = new ToolStripMenuItem();
            nhaSanXuatToolStripMenuItem = new ToolStripMenuItem();
            mauSacToolStripMenuItem = new ToolStripMenuItem();
            anhToolStripMenuItem = new ToolStripMenuItem();
            rjDropdownMenu2 = new Helpers.RJDropdownMenu(components);
            toolStripMenuItem1 = new ToolStripMenuItem();
            toolStripMenuItem2 = new ToolStripMenuItem();
            toolStripMenuItem3 = new ToolStripMenuItem();
            toolStripMenuItem4 = new ToolStripMenuItem();
            toolStripMenuItem5 = new ToolStripMenuItem();
            toolStripMenuItem6 = new ToolStripMenuItem();
            toolStripMenuItem7 = new ToolStripMenuItem();
            toolStripMenuItem8 = new ToolStripMenuItem();
            rjDropdownMenu3 = new Helpers.RJDropdownMenu(components);
            toolStripMenuItem9 = new ToolStripMenuItem();
            toolStripMenuItem10 = new ToolStripMenuItem();
            toolStripMenuItem11 = new ToolStripMenuItem();
            toolStripMenuItem12 = new ToolStripMenuItem();
            toolStripMenuItem13 = new ToolStripMenuItem();
            toolStripMenuItem14 = new ToolStripMenuItem();
            toolStripMenuItem15 = new ToolStripMenuItem();
            toolStripMenuItem16 = new ToolStripMenuItem();
            rjDropdownMenu4 = new Helpers.RJDropdownMenu(components);
            đăngXuấtToolStripMenuItem = new ToolStripMenuItem();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            rjDropdownMenu1.SuspendLayout();
            rjDropdownMenu2.SuspendLayout();
            rjDropdownMenu3.SuspendLayout();
            rjDropdownMenu4.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ControlLight;
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(btnCaiDat);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(btnThongKe);
            panel1.Controls.Add(btnDanhMuc);
            panel1.Controls.Add(btnKhachHang);
            panel1.Controls.Add(btnHoaDon);
            panel1.Controls.Add(btnDonHang);
            panel1.Controls.Add(btnSanPham);
            panel1.Location = new Point(2, 1);
            panel1.Name = "panel1";
            panel1.Size = new Size(197, 577);
            panel1.TabIndex = 0;
            // 
            // btnCaiDat
            // 
            btnCaiDat.BackColor = Color.LightSeaGreen;
            btnCaiDat.Font = new Font("Times New Roman", 15F, FontStyle.Italic);
            btnCaiDat.ForeColor = Color.Cornsilk;
            btnCaiDat.Location = new Point(1, 406);
            btnCaiDat.Name = "btnCaiDat";
            btnCaiDat.Size = new Size(191, 46);
            btnCaiDat.TabIndex = 4;
            btnCaiDat.Text = "Cài Đặt";
            btnCaiDat.UseVisualStyleBackColor = false;
            btnCaiDat.Click += btnCaiDat_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.running_shoe1;
            pictureBox1.Location = new Point(3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(188, 84);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            // 
            // btnThongKe
            // 
            btnThongKe.BackColor = Color.LightSeaGreen;
            btnThongKe.Font = new Font("Times New Roman", 15F, FontStyle.Italic);
            btnThongKe.ForeColor = Color.Cornsilk;
            btnThongKe.Location = new Point(0, 354);
            btnThongKe.Name = "btnThongKe";
            btnThongKe.Size = new Size(191, 46);
            btnThongKe.TabIndex = 0;
            btnThongKe.Text = "Thống Kê";
            btnThongKe.UseVisualStyleBackColor = false;
            btnThongKe.Click += btnThongKe_Click;
            // 
            // btnDanhMuc
            // 
            btnDanhMuc.BackColor = Color.DarkSeaGreen;
            btnDanhMuc.Font = new Font("Times New Roman", 15F, FontStyle.Italic);
            btnDanhMuc.ForeColor = Color.Cornsilk;
            btnDanhMuc.Location = new Point(0, 302);
            btnDanhMuc.Name = "btnDanhMuc";
            btnDanhMuc.Size = new Size(191, 46);
            btnDanhMuc.TabIndex = 0;
            btnDanhMuc.Text = "Danh Mục";
            btnDanhMuc.UseVisualStyleBackColor = false;
            btnDanhMuc.Click += btnDanhMuc_Click;
            // 
            // btnKhachHang
            // 
            btnKhachHang.BackColor = Color.YellowGreen;
            btnKhachHang.Font = new Font("Times New Roman", 15F, FontStyle.Italic);
            btnKhachHang.ForeColor = Color.Cornsilk;
            btnKhachHang.Location = new Point(0, 250);
            btnKhachHang.Name = "btnKhachHang";
            btnKhachHang.Size = new Size(191, 46);
            btnKhachHang.TabIndex = 0;
            btnKhachHang.Text = "Khách Hàng";
            btnKhachHang.UseVisualStyleBackColor = false;
            // 
            // btnHoaDon
            // 
            btnHoaDon.BackColor = Color.Coral;
            btnHoaDon.Font = new Font("Times New Roman", 15F, FontStyle.Italic);
            btnHoaDon.ForeColor = Color.Cornsilk;
            btnHoaDon.Location = new Point(0, 198);
            btnHoaDon.Name = "btnHoaDon";
            btnHoaDon.Size = new Size(191, 46);
            btnHoaDon.TabIndex = 0;
            btnHoaDon.Text = "Hóa Đơn";
            btnHoaDon.UseVisualStyleBackColor = false;
            btnHoaDon.Click += btnHoaDon_Click;
            // 
            // btnDonHang
            // 
            btnDonHang.BackColor = SystemColors.ActiveCaption;
            btnDonHang.Font = new Font("Times New Roman", 15F, FontStyle.Italic);
            btnDonHang.ForeColor = Color.Cornsilk;
            btnDonHang.Location = new Point(0, 146);
            btnDonHang.Name = "btnDonHang";
            btnDonHang.Size = new Size(191, 46);
            btnDonHang.TabIndex = 0;
            btnDonHang.Text = "Đơn Hàng";
            btnDonHang.UseVisualStyleBackColor = false;
            btnDonHang.Click += btnDonHang_Click;
            // 
            // btnSanPham
            // 
            btnSanPham.BackColor = SystemColors.AppWorkspace;
            btnSanPham.BackgroundImage = (Image)resources.GetObject("btnSanPham.BackgroundImage");
            btnSanPham.Font = new Font("Times New Roman", 15F, FontStyle.Italic);
            btnSanPham.ForeColor = Color.Cornsilk;
            btnSanPham.ImageAlign = ContentAlignment.MiddleLeft;
            btnSanPham.Location = new Point(0, 94);
            btnSanPham.Name = "btnSanPham";
            btnSanPham.Size = new Size(191, 46);
            btnSanPham.TabIndex = 0;
            btnSanPham.Text = "Sản Phẩm";
            btnSanPham.UseVisualStyleBackColor = false;
            btnSanPham.Click += btnSanPham_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(255, 255, 192);
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(label5);
            panel2.Location = new Point(204, 5);
            panel2.Name = "panel2";
            panel2.Size = new Size(1044, 45);
            panel2.TabIndex = 1;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Snap ITC", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(386, 7);
            label5.Name = "label5";
            label5.Size = new Size(291, 31);
            label5.TabIndex = 5;
            label5.Text = "Nhà Shoes-Sneakers";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            label1.ForeColor = Color.Tomato;
            label1.Location = new Point(3, 5);
            label1.Name = "label1";
            label1.Size = new Size(77, 20);
            label1.TabIndex = 0;
            label1.Text = "Xin chào: ";
            // 
            // lblUserName
            // 
            lblUserName.AutoSize = true;
            lblUserName.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblUserName.ForeColor = Color.Tomato;
            lblUserName.Location = new Point(77, 5);
            lblUserName.Name = "lblUserName";
            lblUserName.Size = new Size(41, 20);
            lblUserName.TabIndex = 0;
            lblUserName.Text = "User";
            // 
            // panel3
            // 
            panel3.BackColor = SystemColors.GradientInactiveCaption;
            panel3.BorderStyle = BorderStyle.FixedSingle;
            panel3.Controls.Add(label1);
            panel3.Controls.Add(lblUserName);
            panel3.Location = new Point(204, 546);
            panel3.Name = "panel3";
            panel3.Size = new Size(1044, 30);
            panel3.TabIndex = 2;
            // 
            // pnContent
            // 
            pnContent.BorderStyle = BorderStyle.FixedSingle;
            pnContent.Location = new Point(204, 56);
            pnContent.Name = "pnContent";
            pnContent.Size = new Size(1044, 484);
            pnContent.TabIndex = 3;
            // 
            // rjDropdownMenu1
            // 
            rjDropdownMenu1.IsMainMenu = false;
            rjDropdownMenu1.Items.AddRange(new ToolStripItem[] { kieuDanhMucToolStripMenuItem, danhMucToolStripMenuItem, loaiGiayToolStripMenuItem, sizeGiayToolStripMenuItem, chatLieuToolStripMenuItem, nhaSanXuatToolStripMenuItem, mauSacToolStripMenuItem, anhToolStripMenuItem });
            rjDropdownMenu1.MenuItemTextColor = Color.DarkGray;
            rjDropdownMenu1.Name = "rjDropdownMenu1";
            rjDropdownMenu1.PrimaryColor = Color.MediumSlateBlue;
            rjDropdownMenu1.Size = new Size(156, 180);
            // 
            // kieuDanhMucToolStripMenuItem
            // 
            kieuDanhMucToolStripMenuItem.Name = "kieuDanhMucToolStripMenuItem";
            kieuDanhMucToolStripMenuItem.Size = new Size(155, 22);
            kieuDanhMucToolStripMenuItem.Text = "Kiểu Danh Mục";
            kieuDanhMucToolStripMenuItem.Click += kieuDanhMucToolStripMenuItem_Click;
            // 
            // danhMucToolStripMenuItem
            // 
            danhMucToolStripMenuItem.Name = "danhMucToolStripMenuItem";
            danhMucToolStripMenuItem.Size = new Size(155, 22);
            danhMucToolStripMenuItem.Text = "Danh Mục";
            danhMucToolStripMenuItem.Click += danhMucToolStripMenuItem_Click;
            // 
            // loaiGiayToolStripMenuItem
            // 
            loaiGiayToolStripMenuItem.Name = "loaiGiayToolStripMenuItem";
            loaiGiayToolStripMenuItem.Size = new Size(155, 22);
            loaiGiayToolStripMenuItem.Text = "Loại Giày";
            loaiGiayToolStripMenuItem.Click += loaiGiayToolStripMenuItem_Click;
            // 
            // sizeGiayToolStripMenuItem
            // 
            sizeGiayToolStripMenuItem.Name = "sizeGiayToolStripMenuItem";
            sizeGiayToolStripMenuItem.Size = new Size(155, 22);
            sizeGiayToolStripMenuItem.Text = "Size Giày";
            sizeGiayToolStripMenuItem.Click += sizeGiayToolStripMenuItem_Click;
            // 
            // chatLieuToolStripMenuItem
            // 
            chatLieuToolStripMenuItem.Name = "chatLieuToolStripMenuItem";
            chatLieuToolStripMenuItem.Size = new Size(155, 22);
            chatLieuToolStripMenuItem.Text = "Chất Liệu";
            chatLieuToolStripMenuItem.Click += chatLieuToolStripMenuItem_Click;
            // 
            // nhaSanXuatToolStripMenuItem
            // 
            nhaSanXuatToolStripMenuItem.Name = "nhaSanXuatToolStripMenuItem";
            nhaSanXuatToolStripMenuItem.Size = new Size(155, 22);
            nhaSanXuatToolStripMenuItem.Text = "Nhà Sản Xuất";
            nhaSanXuatToolStripMenuItem.Click += nhaSanXuatToolStripMenuItem_Click;
            // 
            // mauSacToolStripMenuItem
            // 
            mauSacToolStripMenuItem.Name = "mauSacToolStripMenuItem";
            mauSacToolStripMenuItem.Size = new Size(155, 22);
            mauSacToolStripMenuItem.Text = "Màu Sắc";
            mauSacToolStripMenuItem.Click += mauSacToolStripMenuItem_Click;
            // 
            // anhToolStripMenuItem
            // 
            anhToolStripMenuItem.Name = "anhToolStripMenuItem";
            anhToolStripMenuItem.Size = new Size(155, 22);
            anhToolStripMenuItem.Text = "Ảnh";
            anhToolStripMenuItem.Click += anhToolStripMenuItem_Click;
            // 
            // rjDropdownMenu2
            // 
            rjDropdownMenu2.IsMainMenu = false;
            rjDropdownMenu2.Items.AddRange(new ToolStripItem[] { toolStripMenuItem1, toolStripMenuItem2, toolStripMenuItem3, toolStripMenuItem4, toolStripMenuItem5, toolStripMenuItem6, toolStripMenuItem7, toolStripMenuItem8 });
            rjDropdownMenu2.MenuItemTextColor = Color.DarkGray;
            rjDropdownMenu2.Name = "rjDropdownMenu1";
            rjDropdownMenu2.PrimaryColor = Color.MediumSlateBlue;
            rjDropdownMenu2.Size = new Size(156, 180);
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.Size = new Size(155, 22);
            toolStripMenuItem1.Text = "Kiểu Danh Mục";
            // 
            // toolStripMenuItem2
            // 
            toolStripMenuItem2.Name = "toolStripMenuItem2";
            toolStripMenuItem2.Size = new Size(155, 22);
            toolStripMenuItem2.Text = "Danh Mục";
            // 
            // toolStripMenuItem3
            // 
            toolStripMenuItem3.Name = "toolStripMenuItem3";
            toolStripMenuItem3.Size = new Size(155, 22);
            toolStripMenuItem3.Text = "Loại Giày";
            // 
            // toolStripMenuItem4
            // 
            toolStripMenuItem4.Name = "toolStripMenuItem4";
            toolStripMenuItem4.Size = new Size(155, 22);
            toolStripMenuItem4.Text = "Size Giày";
            // 
            // toolStripMenuItem5
            // 
            toolStripMenuItem5.Name = "toolStripMenuItem5";
            toolStripMenuItem5.Size = new Size(155, 22);
            toolStripMenuItem5.Text = "Chất Liệu";
            // 
            // toolStripMenuItem6
            // 
            toolStripMenuItem6.Name = "toolStripMenuItem6";
            toolStripMenuItem6.Size = new Size(155, 22);
            toolStripMenuItem6.Text = "Nhà Sản Xuất";
            // 
            // toolStripMenuItem7
            // 
            toolStripMenuItem7.Name = "toolStripMenuItem7";
            toolStripMenuItem7.Size = new Size(155, 22);
            toolStripMenuItem7.Text = "Màu Sắc";
            // 
            // toolStripMenuItem8
            // 
            toolStripMenuItem8.Name = "toolStripMenuItem8";
            toolStripMenuItem8.Size = new Size(155, 22);
            toolStripMenuItem8.Text = "Ảnh";
            // 
            // rjDropdownMenu3
            // 
            rjDropdownMenu3.IsMainMenu = false;
            rjDropdownMenu3.Items.AddRange(new ToolStripItem[] { toolStripMenuItem9, toolStripMenuItem10, toolStripMenuItem11, toolStripMenuItem12, toolStripMenuItem13, toolStripMenuItem14, toolStripMenuItem15, toolStripMenuItem16 });
            rjDropdownMenu3.MenuItemTextColor = Color.DarkGray;
            rjDropdownMenu3.Name = "rjDropdownMenu1";
            rjDropdownMenu3.PrimaryColor = Color.MediumSlateBlue;
            rjDropdownMenu3.Size = new Size(156, 180);
            // 
            // toolStripMenuItem9
            // 
            toolStripMenuItem9.Name = "toolStripMenuItem9";
            toolStripMenuItem9.Size = new Size(155, 22);
            toolStripMenuItem9.Text = "Kiểu Danh Mục";
            // 
            // toolStripMenuItem10
            // 
            toolStripMenuItem10.Name = "toolStripMenuItem10";
            toolStripMenuItem10.Size = new Size(155, 22);
            toolStripMenuItem10.Text = "Danh Mục";
            // 
            // toolStripMenuItem11
            // 
            toolStripMenuItem11.Name = "toolStripMenuItem11";
            toolStripMenuItem11.Size = new Size(155, 22);
            toolStripMenuItem11.Text = "Loại Giày";
            // 
            // toolStripMenuItem12
            // 
            toolStripMenuItem12.Name = "toolStripMenuItem12";
            toolStripMenuItem12.Size = new Size(155, 22);
            toolStripMenuItem12.Text = "Size Giày";
            // 
            // toolStripMenuItem13
            // 
            toolStripMenuItem13.Name = "toolStripMenuItem13";
            toolStripMenuItem13.Size = new Size(155, 22);
            toolStripMenuItem13.Text = "Chất Liệu";
            // 
            // toolStripMenuItem14
            // 
            toolStripMenuItem14.Name = "toolStripMenuItem14";
            toolStripMenuItem14.Size = new Size(155, 22);
            toolStripMenuItem14.Text = "Nhà Sản Xuất";
            // 
            // toolStripMenuItem15
            // 
            toolStripMenuItem15.Name = "toolStripMenuItem15";
            toolStripMenuItem15.Size = new Size(155, 22);
            toolStripMenuItem15.Text = "Màu Sắc";
            // 
            // toolStripMenuItem16
            // 
            toolStripMenuItem16.Name = "toolStripMenuItem16";
            toolStripMenuItem16.Size = new Size(155, 22);
            toolStripMenuItem16.Text = "Ảnh";
            // 
            // rjDropdownMenu4
            // 
            rjDropdownMenu4.IsMainMenu = false;
            rjDropdownMenu4.Items.AddRange(new ToolStripItem[] { đăngXuấtToolStripMenuItem });
            rjDropdownMenu4.MenuItemTextColor = Color.DarkGray;
            rjDropdownMenu4.Name = "rjDropdownMenu4";
            rjDropdownMenu4.PrimaryColor = Color.MediumSlateBlue;
            rjDropdownMenu4.Size = new Size(130, 26);
            // 
            // đăngXuấtToolStripMenuItem
            // 
            đăngXuấtToolStripMenuItem.Name = "đăngXuấtToolStripMenuItem";
            đăngXuấtToolStripMenuItem.Size = new Size(129, 22);
            đăngXuấtToolStripMenuItem.Text = "Đăng Xuất";
            đăngXuấtToolStripMenuItem.Click += đăngXuấtToolStripMenuItem_Click;
            // 
            // frmMain
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1250, 580);
            Controls.Add(pnContent);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            MaximizeBox = false;
            MinimizeBox = false;
            MinimumSize = new Size(1068, 549);
            Name = "frmMain";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Snakers Store";
            Load += frmMain_Load;
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            rjDropdownMenu1.ResumeLayout(false);
            rjDropdownMenu2.ResumeLayout(false);
            rjDropdownMenu3.ResumeLayout(false);
            rjDropdownMenu4.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button btnSanPham;
        private Button btnDonHang;
        private Button btnHoaDon;
        private Button btnKhachHang;
        private Button btnThongKe;
        private Button btnDanhMuc;
        private Panel panel2;
        private Label lblUserName;
        private Label label1;
        private Label label5;
        private Panel panel3;
        private PictureBox pictureBox1;
        private Panel pnContent;
        private Helpers.RJDropdownMenu rjDropdownMenu1;
        private ToolStripMenuItem kieuDanhMucToolStripMenuItem;
        private ToolStripMenuItem danhMucToolStripMenuItem;
        private ToolStripMenuItem loaiGiayToolStripMenuItem;
        private ToolStripMenuItem sizeGiayToolStripMenuItem;
        private ToolStripMenuItem chatLieuToolStripMenuItem;
        private ToolStripMenuItem nhaSanXuatToolStripMenuItem;
        private ToolStripMenuItem mauSacToolStripMenuItem;
        private ToolStripMenuItem anhToolStripMenuItem;
        private Button btnCaiDat;
        private Helpers.RJDropdownMenu rjDropdownMenu2;
        private ToolStripMenuItem toolStripMenuItem1;
        private ToolStripMenuItem toolStripMenuItem2;
        private ToolStripMenuItem toolStripMenuItem3;
        private ToolStripMenuItem toolStripMenuItem4;
        private ToolStripMenuItem toolStripMenuItem5;
        private ToolStripMenuItem toolStripMenuItem6;
        private ToolStripMenuItem toolStripMenuItem7;
        private ToolStripMenuItem toolStripMenuItem8;
        private Helpers.RJDropdownMenu rjDropdownMenu3;
        private ToolStripMenuItem toolStripMenuItem9;
        private ToolStripMenuItem toolStripMenuItem10;
        private ToolStripMenuItem toolStripMenuItem11;
        private ToolStripMenuItem toolStripMenuItem12;
        private ToolStripMenuItem toolStripMenuItem13;
        private ToolStripMenuItem toolStripMenuItem14;
        private ToolStripMenuItem toolStripMenuItem15;
        private ToolStripMenuItem toolStripMenuItem16;
        private Helpers.RJDropdownMenu rjDropdownMenu4;
        private ToolStripMenuItem đăngXuấtToolStripMenuItem;
    }
}