﻿namespace _3_PL.Views
{
    partial class FrmNhanVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            groupBox1 = new GroupBox();
            chkbHoatdong = new CheckBox();
            label12 = new Label();
            rdbNu = new RadioButton();
            rdbnam = new RadioButton();
            label11 = new Label();
            dtNamSinh = new DateTimePicker();
            label10 = new Label();
            cmbChuVu = new ComboBox();
            label9 = new Label();
            txtMatKhau = new TextBox();
            label8 = new Label();
            txtCMND = new TextBox();
            label7 = new Label();
            txtQueQuan = new TextBox();
            label6 = new Label();
            txtSDT = new TextBox();
            label5 = new Label();
            txtEmail = new TextBox();
            label4 = new Label();
            txtTen = new TextBox();
            label3 = new Label();
            txtHo = new TextBox();
            label2 = new Label();
            txtMa = new TextBox();
            label1 = new Label();
            groupBox2 = new GroupBox();
            btnChonAnh = new Button();
            ptbAnh = new PictureBox();
            btnLuu = new Button();
            btnClear = new Button();
            btnXoa = new Button();
            btnSua = new Button();
            btnThem = new Button();
            txtTimKiem = new TextBox();
            btnTimKiem = new Button();
            dgvNhanVien = new DataGridView();
            idDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            maDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            hoDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            tenDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            gioiTinhDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            namSinhDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            queQuanDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            sdtDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            matKhauDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            emailDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            cMNDDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            idCvDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            trangThaiDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            anhDataGridViewImageColumn = new DataGridViewImageColumn();
            nhanVienViewModelsBindingSource = new BindingSource(components);
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ptbAnh).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvNhanVien).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nhanVienViewModelsBindingSource).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(chkbHoatdong);
            groupBox1.Controls.Add(label12);
            groupBox1.Controls.Add(rdbNu);
            groupBox1.Controls.Add(rdbnam);
            groupBox1.Controls.Add(label11);
            groupBox1.Controls.Add(dtNamSinh);
            groupBox1.Controls.Add(label10);
            groupBox1.Controls.Add(cmbChuVu);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(txtMatKhau);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(txtCMND);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(txtQueQuan);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(txtSDT);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(txtEmail);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(txtTen);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(txtHo);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(txtMa);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(10, 7);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(489, 267);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thông Tin";
            // 
            // chkbHoatdong
            // 
            chkbHoatdong.AutoSize = true;
            chkbHoatdong.Location = new Point(325, 229);
            chkbHoatdong.Name = "chkbHoatdong";
            chkbHoatdong.Size = new Size(112, 19);
            chkbHoatdong.TabIndex = 24;
            chkbHoatdong.Text = "Đang hoạt động";
            chkbHoatdong.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(267, 233);
            label12.Name = "label12";
            label12.Size = new Size(0, 15);
            label12.TabIndex = 23;
            // 
            // rdbNu
            // 
            rdbNu.AutoSize = true;
            rdbNu.Location = new Point(391, 193);
            rdbNu.Name = "rdbNu";
            rdbNu.Size = new Size(41, 19);
            rdbNu.TabIndex = 22;
            rdbNu.TabStop = true;
            rdbNu.Text = "Nữ";
            rdbNu.UseVisualStyleBackColor = true;
            // 
            // rdbnam
            // 
            rdbnam.AutoSize = true;
            rdbnam.Location = new Point(326, 194);
            rdbnam.Name = "rdbnam";
            rdbnam.Size = new Size(51, 19);
            rdbnam.TabIndex = 21;
            rdbnam.TabStop = true;
            rdbnam.Text = "Nam";
            rdbnam.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(262, 197);
            label11.Name = "label11";
            label11.Size = new Size(57, 15);
            label11.TabIndex = 20;
            label11.Text = "Giới Tính:";
            // 
            // dtNamSinh
            // 
            dtNamSinh.CustomFormat = "dd/MM/yyyy";
            dtNamSinh.Format = DateTimePickerFormat.Custom;
            dtNamSinh.Location = new Point(325, 20);
            dtNamSinh.Name = "dtNamSinh";
            dtNamSinh.Size = new Size(152, 23);
            dtNamSinh.TabIndex = 19;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(257, 28);
            label10.Name = "label10";
            label10.Size = new Size(62, 15);
            label10.TabIndex = 18;
            label10.Text = "Năm Sinh:";
            // 
            // cmbChuVu
            // 
            cmbChuVu.FormattingEnabled = true;
            cmbChuVu.Location = new Point(79, 25);
            cmbChuVu.Name = "cmbChuVu";
            cmbChuVu.Size = new Size(156, 23);
            cmbChuVu.TabIndex = 17;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(22, 28);
            label9.Name = "label9";
            label9.Size = new Size(55, 15);
            label9.TabIndex = 16;
            label9.Text = "Chức Vụ:";
            // 
            // txtMatKhau
            // 
            txtMatKhau.Location = new Point(325, 154);
            txtMatKhau.Name = "txtMatKhau";
            txtMatKhau.Size = new Size(153, 23);
            txtMatKhau.TabIndex = 15;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(258, 162);
            label8.Name = "label8";
            label8.Size = new Size(61, 15);
            label8.TabIndex = 14;
            label8.Text = "Mật Khẩu:";
            // 
            // txtCMND
            // 
            txtCMND.Location = new Point(325, 104);
            txtCMND.Name = "txtCMND";
            txtCMND.Size = new Size(153, 23);
            txtCMND.TabIndex = 13;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(258, 112);
            label7.Name = "label7";
            label7.Size = new Size(46, 15);
            label7.TabIndex = 12;
            label7.Text = "CMND:";
            // 
            // txtQueQuan
            // 
            txtQueQuan.Location = new Point(325, 57);
            txtQueQuan.Name = "txtQueQuan";
            txtQueQuan.Size = new Size(153, 23);
            txtQueQuan.TabIndex = 11;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(255, 65);
            label6.Name = "label6";
            label6.Size = new Size(64, 15);
            label6.TabIndex = 10;
            label6.Text = "Quê Quán:";
            // 
            // txtSDT
            // 
            txtSDT.Location = new Point(82, 234);
            txtSDT.Name = "txtSDT";
            txtSDT.Size = new Size(153, 23);
            txtSDT.TabIndex = 9;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(27, 242);
            label5.Name = "label5";
            label5.Size = new Size(29, 15);
            label5.TabIndex = 8;
            label5.Text = "SDT:";
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(82, 194);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(153, 23);
            txtEmail.TabIndex = 7;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(27, 202);
            label4.Name = "label4";
            label4.Size = new Size(39, 15);
            label4.TabIndex = 6;
            label4.Text = "Email:";
            // 
            // txtTen
            // 
            txtTen.Location = new Point(82, 151);
            txtTen.Name = "txtTen";
            txtTen.Size = new Size(153, 23);
            txtTen.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(27, 159);
            label3.Name = "label3";
            label3.Size = new Size(28, 15);
            label3.TabIndex = 4;
            label3.Text = "Tên:";
            // 
            // txtHo
            // 
            txtHo.Location = new Point(82, 108);
            txtHo.Name = "txtHo";
            txtHo.Size = new Size(153, 23);
            txtHo.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(27, 116);
            label2.Name = "label2";
            label2.Size = new Size(26, 15);
            label2.TabIndex = 2;
            label2.Text = "Họ:";
            // 
            // txtMa
            // 
            txtMa.Location = new Point(82, 65);
            txtMa.Name = "txtMa";
            txtMa.Size = new Size(153, 23);
            txtMa.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(27, 73);
            label1.Name = "label1";
            label1.Size = new Size(27, 15);
            label1.TabIndex = 0;
            label1.Text = "Mã:";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(btnChonAnh);
            groupBox2.Controls.Add(ptbAnh);
            groupBox2.Controls.Add(btnLuu);
            groupBox2.Controls.Add(btnClear);
            groupBox2.Controls.Add(btnXoa);
            groupBox2.Controls.Add(btnSua);
            groupBox2.Controls.Add(btnThem);
            groupBox2.Location = new Point(524, 12);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(315, 262);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Chức Năng";
            // 
            // btnChonAnh
            // 
            btnChonAnh.Location = new Point(165, 173);
            btnChonAnh.Name = "btnChonAnh";
            btnChonAnh.Size = new Size(104, 34);
            btnChonAnh.TabIndex = 6;
            btnChonAnh.Text = "Chọn Ảnh";
            btnChonAnh.UseVisualStyleBackColor = true;
            btnChonAnh.Click += btnChonAnh_Click;
            // 
            // ptbAnh
            // 
            ptbAnh.BackColor = Color.FromArgb(192, 255, 255);
            ptbAnh.Location = new Point(139, 23);
            ptbAnh.Name = "ptbAnh";
            ptbAnh.Size = new Size(166, 132);
            ptbAnh.TabIndex = 5;
            ptbAnh.TabStop = false;
            // 
            // btnLuu
            // 
            btnLuu.Location = new Point(13, 197);
            btnLuu.Name = "btnLuu";
            btnLuu.Size = new Size(104, 34);
            btnLuu.TabIndex = 4;
            btnLuu.Text = "Lưu";
            btnLuu.UseVisualStyleBackColor = true;
            btnLuu.Click += btnLuu_Click;
            // 
            // btnClear
            // 
            btnClear.Location = new Point(13, 154);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(104, 34);
            btnClear.TabIndex = 3;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += btnClear_Click;
            // 
            // btnXoa
            // 
            btnXoa.Location = new Point(13, 111);
            btnXoa.Name = "btnXoa";
            btnXoa.Size = new Size(104, 34);
            btnXoa.TabIndex = 2;
            btnXoa.Text = "Xóa";
            btnXoa.UseVisualStyleBackColor = true;
            btnXoa.Click += btnXoa_Click;
            // 
            // btnSua
            // 
            btnSua.Location = new Point(13, 71);
            btnSua.Name = "btnSua";
            btnSua.Size = new Size(104, 34);
            btnSua.TabIndex = 1;
            btnSua.Text = "Sửa";
            btnSua.UseVisualStyleBackColor = true;
            btnSua.Click += btnSua_Click;
            // 
            // btnThem
            // 
            btnThem.Location = new Point(13, 31);
            btnThem.Name = "btnThem";
            btnThem.Size = new Size(104, 34);
            btnThem.TabIndex = 0;
            btnThem.Text = "Thêm";
            btnThem.UseVisualStyleBackColor = true;
            btnThem.Click += btnThem_Click;
            // 
            // txtTimKiem
            // 
            txtTimKiem.Location = new Point(214, 280);
            txtTimKiem.Name = "txtTimKiem";
            txtTimKiem.Size = new Size(228, 23);
            txtTimKiem.TabIndex = 11;
            // 
            // btnTimKiem
            // 
            btnTimKiem.Location = new Point(133, 280);
            btnTimKiem.Name = "btnTimKiem";
            btnTimKiem.Size = new Size(75, 23);
            btnTimKiem.TabIndex = 12;
            btnTimKiem.Text = "Tìm kiếm";
            btnTimKiem.UseVisualStyleBackColor = true;
            btnTimKiem.Click += btnTimKiem_Click;
            // 
            // dgvNhanVien
            // 
            dgvNhanVien.AutoGenerateColumns = false;
            dgvNhanVien.BackgroundColor = SystemColors.ButtonFace;
            dgvNhanVien.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvNhanVien.Columns.AddRange(new DataGridViewColumn[] { idDataGridViewTextBoxColumn, maDataGridViewTextBoxColumn, hoDataGridViewTextBoxColumn, tenDataGridViewTextBoxColumn, gioiTinhDataGridViewTextBoxColumn, namSinhDataGridViewTextBoxColumn, queQuanDataGridViewTextBoxColumn, sdtDataGridViewTextBoxColumn, matKhauDataGridViewTextBoxColumn, emailDataGridViewTextBoxColumn, cMNDDataGridViewTextBoxColumn, idCvDataGridViewTextBoxColumn, trangThaiDataGridViewTextBoxColumn, anhDataGridViewImageColumn });
            dgvNhanVien.DataSource = nhanVienViewModelsBindingSource;
            dgvNhanVien.Location = new Point(10, 320);
            dgvNhanVien.Name = "dgvNhanVien";
            dgvNhanVien.Size = new Size(829, 165);
            dgvNhanVien.TabIndex = 13;
            dgvNhanVien.CellClick += dgvNhanVien_CellClick;
            dgvNhanVien.CellContentClick += dgvNhanVien_CellContentClick;
            // 
            // idDataGridViewTextBoxColumn
            // 
            idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            idDataGridViewTextBoxColumn.HeaderText = "Id";
            idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            // 
            // maDataGridViewTextBoxColumn
            // 
            maDataGridViewTextBoxColumn.DataPropertyName = "Ma";
            maDataGridViewTextBoxColumn.HeaderText = "Ma";
            maDataGridViewTextBoxColumn.Name = "maDataGridViewTextBoxColumn";
            // 
            // hoDataGridViewTextBoxColumn
            // 
            hoDataGridViewTextBoxColumn.DataPropertyName = "Ho";
            hoDataGridViewTextBoxColumn.HeaderText = "Ho";
            hoDataGridViewTextBoxColumn.Name = "hoDataGridViewTextBoxColumn";
            // 
            // tenDataGridViewTextBoxColumn
            // 
            tenDataGridViewTextBoxColumn.DataPropertyName = "Ten";
            tenDataGridViewTextBoxColumn.HeaderText = "Ten";
            tenDataGridViewTextBoxColumn.Name = "tenDataGridViewTextBoxColumn";
            // 
            // gioiTinhDataGridViewTextBoxColumn
            // 
            gioiTinhDataGridViewTextBoxColumn.DataPropertyName = "GioiTinh";
            gioiTinhDataGridViewTextBoxColumn.HeaderText = "GioiTinh";
            gioiTinhDataGridViewTextBoxColumn.Name = "gioiTinhDataGridViewTextBoxColumn";
            // 
            // namSinhDataGridViewTextBoxColumn
            // 
            namSinhDataGridViewTextBoxColumn.DataPropertyName = "NamSinh";
            namSinhDataGridViewTextBoxColumn.HeaderText = "NamSinh";
            namSinhDataGridViewTextBoxColumn.Name = "namSinhDataGridViewTextBoxColumn";
            // 
            // queQuanDataGridViewTextBoxColumn
            // 
            queQuanDataGridViewTextBoxColumn.DataPropertyName = "QueQuan";
            queQuanDataGridViewTextBoxColumn.HeaderText = "QueQuan";
            queQuanDataGridViewTextBoxColumn.Name = "queQuanDataGridViewTextBoxColumn";
            // 
            // sdtDataGridViewTextBoxColumn
            // 
            sdtDataGridViewTextBoxColumn.DataPropertyName = "Sdt";
            sdtDataGridViewTextBoxColumn.HeaderText = "Sdt";
            sdtDataGridViewTextBoxColumn.Name = "sdtDataGridViewTextBoxColumn";
            // 
            // matKhauDataGridViewTextBoxColumn
            // 
            matKhauDataGridViewTextBoxColumn.DataPropertyName = "MatKhau";
            matKhauDataGridViewTextBoxColumn.HeaderText = "MatKhau";
            matKhauDataGridViewTextBoxColumn.Name = "matKhauDataGridViewTextBoxColumn";
            // 
            // emailDataGridViewTextBoxColumn
            // 
            emailDataGridViewTextBoxColumn.DataPropertyName = "Email";
            emailDataGridViewTextBoxColumn.HeaderText = "Email";
            emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
            // 
            // cMNDDataGridViewTextBoxColumn
            // 
            cMNDDataGridViewTextBoxColumn.DataPropertyName = "CMND";
            cMNDDataGridViewTextBoxColumn.HeaderText = "CMND";
            cMNDDataGridViewTextBoxColumn.Name = "cMNDDataGridViewTextBoxColumn";
            // 
            // idCvDataGridViewTextBoxColumn
            // 
            idCvDataGridViewTextBoxColumn.DataPropertyName = "IdCv";
            idCvDataGridViewTextBoxColumn.HeaderText = "IdCv";
            idCvDataGridViewTextBoxColumn.Name = "idCvDataGridViewTextBoxColumn";
            // 
            // trangThaiDataGridViewTextBoxColumn
            // 
            trangThaiDataGridViewTextBoxColumn.DataPropertyName = "TrangThai";
            trangThaiDataGridViewTextBoxColumn.HeaderText = "TrangThai";
            trangThaiDataGridViewTextBoxColumn.Name = "trangThaiDataGridViewTextBoxColumn";
            // 
            // anhDataGridViewImageColumn
            // 
            anhDataGridViewImageColumn.DataPropertyName = "Anh";
            anhDataGridViewImageColumn.HeaderText = "Anh";
            anhDataGridViewImageColumn.Name = "anhDataGridViewImageColumn";
            // 
            // nhanVienViewModelsBindingSource
            // 
            nhanVienViewModelsBindingSource.DataSource = typeof(_2_BUS.ViewModels.NhanVienViewModels);
            // 
            // FrmNhanVien
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(870, 497);
            Controls.Add(dgvNhanVien);
            Controls.Add(btnTimKiem);
            Controls.Add(txtTimKiem);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "FrmNhanVien";
            Text = "FrmNhanVien";
            Load += FrmNhanVien_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)ptbAnh).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvNhanVien).EndInit();
            ((System.ComponentModel.ISupportInitialize)nhanVienViewModelsBindingSource).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private TextBox txtMatKhau;
        private Label label8;
        private TextBox txtCMND;
        private Label label7;
        private TextBox txtQueQuan;
        private Label label6;
        private TextBox txtSDT;
        private Label label5;
        private TextBox txtEmail;
        private Label label4;
        private TextBox txtTen;
        private Label label3;
        private TextBox txtHo;
        private Label label2;
        private TextBox txtMa;
        private Label label1;
        private RadioButton rdbNu;
        private RadioButton rdbnam;
        private Label label11;
        private DateTimePicker dtNamSinh;
        private Label label10;
        private ComboBox cmbChuVu;
        private Label label9;
        private CheckBox chkbHoatdong;
        private Label label12;
        private GroupBox groupBox2;
        private Button btnChonAnh;
        private PictureBox ptbAnh;
        private Button btnLuu;
        private Button btnClear;
        private Button btnXoa;
        private Button btnSua;
        private Button btnThem;
        private TextBox txtTimKiem;
        private Button btnTimKiem;
        private DataGridView dgvNhanVien;
        private BindingSource nhanVienViewModelsBindingSource;
        private DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn maDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn hoDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn tenDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn gioiTinhDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn namSinhDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn queQuanDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn sdtDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn matKhauDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn cMNDDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn idCvDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn trangThaiDataGridViewTextBoxColumn;
        private DataGridViewImageColumn anhDataGridViewImageColumn;
    }
}