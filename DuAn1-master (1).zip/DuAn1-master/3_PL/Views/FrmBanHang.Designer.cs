﻿namespace _3_PL.Views
{
    partial class FrmBanHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            pckgiamGioHang = new PictureBox();
            pcktanggiohang = new PictureBox();
            btnCapNhap = new Button();
            txtSoLuongGioHang = new TextBox();
            dgvGioHang = new DataGridView();
            groupBox2 = new GroupBox();
            pckTimKiem = new PictureBox();
            txtTimKiem = new TextBox();
            btnVogiohang = new Button();
            pckGiamsp = new PictureBox();
            pckTangsp = new PictureBox();
            textBox1 = new TextBox();
            dgvSanPham = new DataGridView();
            groupBox3 = new GroupBox();
            flThanhToan = new FlowLayoutPanel();
            groupBox4 = new GroupBox();
            flChoGiaoHang = new FlowLayoutPanel();
            pnthongtin = new Panel();
            txtSDT = new TextBox();
            button1 = new Button();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            pnlHoaDon = new Panel();
            textBox3 = new TextBox();
            label13 = new Label();
            label12 = new Label();
            txtTongTien = new TextBox();
            label11 = new Label();
            btnThanhToan = new Button();
            txtGhiChu = new TextBox();
            label10 = new Label();
            rdCho = new RadioButton();
            rdhuy = new RadioButton();
            rddathanhtoan = new RadioButton();
            rdchuathanhtoan = new RadioButton();
            label9 = new Label();
            dtNgaythanhtoan = new DateTimePicker();
            label8 = new Label();
            dtNgayTao = new DateTimePicker();
            label7 = new Label();
            label6 = new Label();
            txtTienTralai = new TextBox();
            label5 = new Label();
            label3 = new Label();
            txtTienKhachDua = new TextBox();
            label4 = new Label();
            label2 = new Label();
            textBox2 = new TextBox();
            label1 = new Label();
            btnDatHang = new Button();
            btnHoaDon = new Button();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            label17 = new Label();
            pictureBox3 = new PictureBox();
            button2 = new Button();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pckgiamGioHang).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pcktanggiohang).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvGioHang).BeginInit();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pckTimKiem).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pckGiamsp).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pckTangsp).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvSanPham).BeginInit();
            groupBox3.SuspendLayout();
            groupBox4.SuspendLayout();
            pnthongtin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            pnlHoaDon.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Silver;
            groupBox1.Controls.Add(pckgiamGioHang);
            groupBox1.Controls.Add(pcktanggiohang);
            groupBox1.Controls.Add(btnCapNhap);
            groupBox1.Controls.Add(txtSoLuongGioHang);
            groupBox1.Controls.Add(dgvGioHang);
            groupBox1.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox1.ForeColor = Color.Red;
            groupBox1.Location = new Point(13, 124);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(534, 222);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Giỏ Hàng";
            // 
            // pckgiamGioHang
            // 
            pckgiamGioHang.Location = new Point(398, 25);
            pckgiamGioHang.Name = "pckgiamGioHang";
            pckgiamGioHang.Size = new Size(30, 20);
            pckgiamGioHang.TabIndex = 4;
            pckgiamGioHang.TabStop = false;
            // 
            // pcktanggiohang
            // 
            pcktanggiohang.Location = new Point(318, 25);
            pcktanggiohang.Name = "pcktanggiohang";
            pcktanggiohang.Size = new Size(30, 20);
            pcktanggiohang.TabIndex = 3;
            pcktanggiohang.TabStop = false;
            // 
            // btnCapNhap
            // 
            btnCapNhap.BackColor = Color.Red;
            btnCapNhap.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnCapNhap.ForeColor = Color.White;
            btnCapNhap.Location = new Point(446, 20);
            btnCapNhap.Name = "btnCapNhap";
            btnCapNhap.Size = new Size(75, 27);
            btnCapNhap.TabIndex = 2;
            btnCapNhap.Text = "Cập Nhập";
            btnCapNhap.UseVisualStyleBackColor = false;
            // 
            // txtSoLuongGioHang
            // 
            txtSoLuongGioHang.Location = new Point(354, 20);
            txtSoLuongGioHang.Name = "txtSoLuongGioHang";
            txtSoLuongGioHang.Size = new Size(38, 27);
            txtSoLuongGioHang.TabIndex = 1;
            txtSoLuongGioHang.Text = "0";
            // 
            // dgvGioHang
            // 
            dgvGioHang.BackgroundColor = Color.White;
            dgvGioHang.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvGioHang.Location = new Point(11, 53);
            dgvGioHang.Name = "dgvGioHang";
            dgvGioHang.Size = new Size(511, 148);
            dgvGioHang.TabIndex = 0;
            // 
            // groupBox2
            // 
            groupBox2.BackColor = Color.Silver;
            groupBox2.Controls.Add(pckTimKiem);
            groupBox2.Controls.Add(txtTimKiem);
            groupBox2.Controls.Add(btnVogiohang);
            groupBox2.Controls.Add(pckGiamsp);
            groupBox2.Controls.Add(pckTangsp);
            groupBox2.Controls.Add(textBox1);
            groupBox2.Controls.Add(dgvSanPham);
            groupBox2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox2.ForeColor = Color.Red;
            groupBox2.Location = new Point(13, 361);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(534, 232);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Thông Tin Sản Phẩm";
            // 
            // pckTimKiem
            // 
            pckTimKiem.Location = new Point(44, 42);
            pckTimKiem.Name = "pckTimKiem";
            pckTimKiem.Size = new Size(30, 20);
            pckTimKiem.TabIndex = 10;
            pckTimKiem.TabStop = false;
            // 
            // txtTimKiem
            // 
            txtTimKiem.Location = new Point(89, 36);
            txtTimKiem.Name = "txtTimKiem";
            txtTimKiem.Size = new Size(152, 29);
            txtTimKiem.TabIndex = 9;
            // 
            // btnVogiohang
            // 
            btnVogiohang.Location = new Point(393, 30);
            btnVogiohang.Name = "btnVogiohang";
            btnVogiohang.Size = new Size(129, 32);
            btnVogiohang.TabIndex = 8;
            btnVogiohang.Text = "Thêm Giỏ Hàng";
            btnVogiohang.UseVisualStyleBackColor = true;
            // 
            // pckGiamsp
            // 
            pckGiamsp.Location = new Point(357, 39);
            pckGiamsp.Name = "pckGiamsp";
            pckGiamsp.Size = new Size(30, 20);
            pckGiamsp.TabIndex = 7;
            pckGiamsp.TabStop = false;
            // 
            // pckTangsp
            // 
            pckTangsp.Location = new Point(277, 39);
            pckTangsp.Name = "pckTangsp";
            pckTangsp.Size = new Size(30, 20);
            pckTangsp.TabIndex = 6;
            pckTangsp.TabStop = false;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(313, 30);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(38, 29);
            textBox1.TabIndex = 5;
            textBox1.Text = "0";
            // 
            // dgvSanPham
            // 
            dgvSanPham.BackgroundColor = Color.White;
            dgvSanPham.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvSanPham.Location = new Point(21, 71);
            dgvSanPham.Name = "dgvSanPham";
            dgvSanPham.Size = new Size(501, 151);
            dgvSanPham.TabIndex = 0;
            dgvSanPham.CellContentClick += dgvSanPham_CellContentClick;
            // 
            // groupBox3
            // 
            groupBox3.BackColor = Color.Silver;
            groupBox3.Controls.Add(flThanhToan);
            groupBox3.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox3.ForeColor = Color.Red;
            groupBox3.Location = new Point(552, 124);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(158, 222);
            groupBox3.TabIndex = 2;
            groupBox3.TabStop = false;
            groupBox3.Text = "Thanh Toán";
            // 
            // flThanhToan
            // 
            flThanhToan.Location = new Point(6, 26);
            flThanhToan.Name = "flThanhToan";
            flThanhToan.Size = new Size(137, 175);
            flThanhToan.TabIndex = 0;
            // 
            // groupBox4
            // 
            groupBox4.BackColor = Color.Silver;
            groupBox4.Controls.Add(flChoGiaoHang);
            groupBox4.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox4.ForeColor = Color.Red;
            groupBox4.Location = new Point(553, 361);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(158, 232);
            groupBox4.TabIndex = 3;
            groupBox4.TabStop = false;
            groupBox4.Text = "Chờ Giao Hàng";
            // 
            // flChoGiaoHang
            // 
            flChoGiaoHang.Location = new Point(6, 26);
            flChoGiaoHang.Name = "flChoGiaoHang";
            flChoGiaoHang.Size = new Size(137, 196);
            flChoGiaoHang.TabIndex = 0;
            // 
            // pnthongtin
            // 
            pnthongtin.BackColor = Color.FromArgb(224, 224, 224);
            pnthongtin.Controls.Add(txtSDT);
            pnthongtin.Controls.Add(button1);
            pnthongtin.Controls.Add(pictureBox2);
            pnthongtin.Controls.Add(pictureBox1);
            pnthongtin.Location = new Point(751, 12);
            pnthongtin.Name = "pnthongtin";
            pnthongtin.Size = new Size(301, 80);
            pnthongtin.TabIndex = 4;
            // 
            // txtSDT
            // 
            txtSDT.Location = new Point(50, 42);
            txtSDT.Name = "txtSDT";
            txtSDT.Size = new Size(132, 23);
            txtSDT.TabIndex = 7;
            txtSDT.Text = "--SĐT Khách Hàng--";
            // 
            // button1
            // 
            button1.Location = new Point(50, 12);
            button1.Name = "button1";
            button1.Size = new Size(134, 24);
            button1.TabIndex = 6;
            button1.Text = "--Tên Nhân Viên--";
            button1.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            pictureBox2.Location = new Point(1, 39);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(30, 20);
            pictureBox2.TabIndex = 5;
            pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(3, 16);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(30, 20);
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // pnlHoaDon
            // 
            pnlHoaDon.BackColor = Color.FromArgb(224, 224, 224);
            pnlHoaDon.Controls.Add(textBox3);
            pnlHoaDon.Controls.Add(label13);
            pnlHoaDon.Controls.Add(label12);
            pnlHoaDon.Controls.Add(txtTongTien);
            pnlHoaDon.Controls.Add(label11);
            pnlHoaDon.Controls.Add(btnThanhToan);
            pnlHoaDon.Controls.Add(txtGhiChu);
            pnlHoaDon.Controls.Add(label10);
            pnlHoaDon.Controls.Add(rdCho);
            pnlHoaDon.Controls.Add(rdhuy);
            pnlHoaDon.Controls.Add(rddathanhtoan);
            pnlHoaDon.Controls.Add(rdchuathanhtoan);
            pnlHoaDon.Controls.Add(label9);
            pnlHoaDon.Controls.Add(dtNgaythanhtoan);
            pnlHoaDon.Controls.Add(label8);
            pnlHoaDon.Controls.Add(dtNgayTao);
            pnlHoaDon.Controls.Add(label7);
            pnlHoaDon.Controls.Add(label6);
            pnlHoaDon.Controls.Add(txtTienTralai);
            pnlHoaDon.Controls.Add(label5);
            pnlHoaDon.Controls.Add(label3);
            pnlHoaDon.Controls.Add(txtTienKhachDua);
            pnlHoaDon.Controls.Add(label4);
            pnlHoaDon.Controls.Add(label2);
            pnlHoaDon.Controls.Add(textBox2);
            pnlHoaDon.Controls.Add(label1);
            pnlHoaDon.Controls.Add(btnDatHang);
            pnlHoaDon.Controls.Add(btnHoaDon);
            pnlHoaDon.Location = new Point(751, 98);
            pnlHoaDon.Name = "pnlHoaDon";
            pnlHoaDon.Size = new Size(301, 495);
            pnlHoaDon.TabIndex = 5;
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.FromArgb(224, 224, 224);
            textBox3.Location = new Point(101, 103);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(156, 23);
            textBox3.TabIndex = 27;
            textBox3.Text = "                           0";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label13.ForeColor = Color.Black;
            label13.Location = new Point(12, 110);
            label13.Name = "label13";
            label13.Size = new Size(60, 17);
            label13.TabIndex = 26;
            label13.Text = "VouCher:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(254, 80);
            label12.Name = "label12";
            label12.Size = new Size(31, 15);
            label12.TabIndex = 25;
            label12.Text = "VNĐ";
            // 
            // txtTongTien
            // 
            txtTongTien.BackColor = Color.FromArgb(224, 224, 224);
            txtTongTien.Location = new Point(124, 74);
            txtTongTien.Name = "txtTongTien";
            txtTongTien.Size = new Size(124, 23);
            txtTongTien.TabIndex = 24;
            txtTongTien.Text = "                           0";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.Red;
            label11.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label11.ForeColor = Color.White;
            label11.Location = new Point(6, 80);
            label11.Name = "label11";
            label11.Size = new Size(105, 17);
            label11.TabIndex = 23;
            label11.Text = "Tổng Tiền (VNĐ)";
            // 
            // btnThanhToan
            // 
            btnThanhToan.BackColor = Color.Red;
            btnThanhToan.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnThanhToan.ForeColor = Color.White;
            btnThanhToan.Location = new Point(101, 416);
            btnThanhToan.Name = "btnThanhToan";
            btnThanhToan.Size = new Size(146, 49);
            btnThanhToan.TabIndex = 22;
            btnThanhToan.Text = "Thanh Toán";
            btnThanhToan.UseVisualStyleBackColor = false;
            // 
            // txtGhiChu
            // 
            txtGhiChu.Location = new Point(95, 385);
            txtGhiChu.Name = "txtGhiChu";
            txtGhiChu.Size = new Size(186, 23);
            txtGhiChu.TabIndex = 21;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(32, 387);
            label10.Name = "label10";
            label10.Size = new Size(53, 15);
            label10.TabIndex = 20;
            label10.Text = "Ghi Chú:";
            // 
            // rdCho
            // 
            rdCho.AutoSize = true;
            rdCho.Location = new Point(178, 312);
            rdCho.Name = "rdCho";
            rdCho.Size = new Size(103, 19);
            rdCho.TabIndex = 19;
            rdCho.TabStop = true;
            rdCho.Text = "Chờ giao hàng";
            rdCho.UseVisualStyleBackColor = true;
            // 
            // rdhuy
            // 
            rdhuy.AutoSize = true;
            rdhuy.Location = new Point(102, 313);
            rdhuy.Name = "rdhuy";
            rdhuy.Size = new Size(62, 19);
            rdhuy.TabIndex = 18;
            rdhuy.TabStop = true;
            rdhuy.Text = "Đã hủy";
            rdhuy.UseVisualStyleBackColor = true;
            // 
            // rddathanhtoan
            // 
            rddathanhtoan.AutoSize = true;
            rddathanhtoan.Location = new Point(186, 344);
            rddathanhtoan.Name = "rddathanhtoan";
            rddathanhtoan.Size = new Size(100, 19);
            rddathanhtoan.TabIndex = 17;
            rddathanhtoan.TabStop = true;
            rddathanhtoan.Text = "Đã thanh toán";
            rddathanhtoan.UseVisualStyleBackColor = true;
            // 
            // rdchuathanhtoan
            // 
            rdchuathanhtoan.AutoSize = true;
            rdchuathanhtoan.Location = new Point(50, 344);
            rdchuathanhtoan.Name = "rdchuathanhtoan";
            rdchuathanhtoan.Size = new Size(114, 19);
            rdchuathanhtoan.TabIndex = 16;
            rdchuathanhtoan.TabStop = true;
            rdchuathanhtoan.Text = "Chưa thanh toán";
            rdchuathanhtoan.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(32, 315);
            label9.Name = "label9";
            label9.Size = new Size(64, 15);
            label9.TabIndex = 15;
            label9.Text = "Trạng Thái:";
            // 
            // dtNgaythanhtoan
            // 
            dtNgaythanhtoan.Format = DateTimePickerFormat.Custom;
            dtNgaythanhtoan.Location = new Point(120, 269);
            dtNgaythanhtoan.Name = "dtNgaythanhtoan";
            dtNgaythanhtoan.Size = new Size(137, 23);
            dtNgaythanhtoan.TabIndex = 14;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(20, 275);
            label8.Name = "label8";
            label8.Size = new Size(102, 15);
            label8.TabIndex = 13;
            label8.Text = "Ngày Thanh Toán:";
            // 
            // dtNgayTao
            // 
            dtNgayTao.Format = DateTimePickerFormat.Custom;
            dtNgayTao.Location = new Point(120, 230);
            dtNgayTao.Name = "dtNgayTao";
            dtNgayTao.Size = new Size(137, 23);
            dtNgayTao.TabIndex = 12;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(27, 238);
            label7.Name = "label7";
            label7.Size = new Size(60, 15);
            label7.TabIndex = 11;
            label7.Text = "Ngày Tạo:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(263, 198);
            label6.Name = "label6";
            label6.Size = new Size(31, 15);
            label6.TabIndex = 10;
            label6.Text = "VNĐ";
            // 
            // txtTienTralai
            // 
            txtTienTralai.BackColor = Color.FromArgb(224, 224, 224);
            txtTienTralai.Location = new Point(117, 190);
            txtTienTralai.Name = "txtTienTralai";
            txtTienTralai.Size = new Size(140, 23);
            txtTienTralai.TabIndex = 9;
            txtTienTralai.Text = "                           0";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Black;
            label5.Location = new Point(17, 196);
            label5.Name = "label5";
            label5.Size = new Size(98, 17);
            label5.TabIndex = 8;
            label5.Text = "Tiền Dư Trả Lại:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(263, 169);
            label3.Name = "label3";
            label3.Size = new Size(31, 15);
            label3.TabIndex = 7;
            label3.Text = "VNĐ";
            // 
            // txtTienKhachDua
            // 
            txtTienKhachDua.BackColor = Color.FromArgb(224, 224, 224);
            txtTienKhachDua.Location = new Point(117, 161);
            txtTienKhachDua.Name = "txtTienKhachDua";
            txtTienKhachDua.Size = new Size(140, 23);
            txtTienKhachDua.TabIndex = 6;
            txtTienKhachDua.Text = "                           0";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Black;
            label4.Location = new Point(17, 167);
            label4.Name = "label4";
            label4.Size = new Size(102, 17);
            label4.TabIndex = 5;
            label4.Text = "Tiền Khách Đưa:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(263, 140);
            label2.Name = "label2";
            label2.Size = new Size(31, 15);
            label2.TabIndex = 4;
            label2.Text = "VNĐ";
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.FromArgb(224, 224, 224);
            textBox2.Location = new Point(117, 132);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(140, 23);
            textBox2.TabIndex = 3;
            textBox2.Text = "                           0";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Red;
            label1.Location = new Point(17, 138);
            label1.Name = "label1";
            label1.Size = new Size(94, 17);
            label1.TabIndex = 2;
            label1.Text = "Khách Cần Trả:";
            // 
            // btnDatHang
            // 
            btnDatHang.BackColor = Color.Red;
            btnDatHang.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnDatHang.ForeColor = Color.White;
            btnDatHang.Location = new Point(174, 11);
            btnDatHang.Name = "btnDatHang";
            btnDatHang.Size = new Size(106, 42);
            btnDatHang.TabIndex = 1;
            btnDatHang.Text = "Đặt Hàng";
            btnDatHang.UseVisualStyleBackColor = false;
            // 
            // btnHoaDon
            // 
            btnHoaDon.BackColor = Color.Red;
            btnHoaDon.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnHoaDon.ForeColor = Color.White;
            btnHoaDon.Location = new Point(12, 9);
            btnHoaDon.Name = "btnHoaDon";
            btnHoaDon.Size = new Size(106, 42);
            btnHoaDon.TabIndex = 0;
            btnHoaDon.Text = "Hóa Đơn";
            btnHoaDon.UseVisualStyleBackColor = false;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(12, 24);
            label14.Name = "label14";
            label14.Size = new Size(60, 15);
            label14.TabIndex = 6;
            label14.Text = "Thời Gian:";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(13, 49);
            label15.Name = "label15";
            label15.Size = new Size(74, 15);
            label15.TabIndex = 7;
            label15.Text = "Ngày Tháng:";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(78, 24);
            label16.Name = "label16";
            label16.Size = new Size(44, 15);
            label16.TabIndex = 8;
            label16.Text = "label16";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(94, 48);
            label17.Name = "label17";
            label17.Size = new Size(44, 15);
            label17.TabIndex = 9;
            label17.Text = "label17";
            // 
            // pictureBox3
            // 
            pictureBox3.Location = new Point(275, 12);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(70, 35);
            pictureBox3.TabIndex = 10;
            pictureBox3.TabStop = false;
            // 
            // button2
            // 
            button2.BackColor = Color.Red;
            button2.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.White;
            button2.Location = new Point(13, 74);
            button2.Name = "button2";
            button2.Size = new Size(110, 43);
            button2.TabIndex = 11;
            button2.Text = "Tạo Hóa Đơn";
            button2.UseVisualStyleBackColor = false;
            // 
            // FrmBanHang
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1252, 689);
            Controls.Add(button2);
            Controls.Add(pictureBox3);
            Controls.Add(label17);
            Controls.Add(label16);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(pnlHoaDon);
            Controls.Add(pnthongtin);
            Controls.Add(groupBox4);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "FrmBanHang";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FrmBanHang";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pckgiamGioHang).EndInit();
            ((System.ComponentModel.ISupportInitialize)pcktanggiohang).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvGioHang).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pckTimKiem).EndInit();
            ((System.ComponentModel.ISupportInitialize)pckGiamsp).EndInit();
            ((System.ComponentModel.ISupportInitialize)pckTangsp).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvSanPham).EndInit();
            groupBox3.ResumeLayout(false);
            groupBox4.ResumeLayout(false);
            pnthongtin.ResumeLayout(false);
            pnthongtin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            pnlHoaDon.ResumeLayout(false);
            pnlHoaDon.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private DataGridView dgvGioHang;
        private PictureBox pckgiamGioHang;
        private PictureBox pcktanggiohang;
        private Button btnCapNhap;
        private TextBox txtSoLuongGioHang;
        private GroupBox groupBox2;
        private DataGridView dgvSanPham;
        private TextBox textBox1;
        private PictureBox pckTimKiem;
        private TextBox txtTimKiem;
        private Button btnVogiohang;
        private PictureBox pckGiamsp;
        private PictureBox pckTangsp;
        private GroupBox groupBox3;
        private FlowLayoutPanel flThanhToan;
        private GroupBox groupBox4;
        private FlowLayoutPanel flChoGiaoHang;
        private Panel pnthongtin;
        private TextBox txtSDT;
        private Button button1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
        private Panel pnlHoaDon;
        private Button btnDatHang;
        private Button btnHoaDon;
        private TextBox textBox2;
        private Label label1;
        private Label label7;
        private Label label6;
        private TextBox txtTienTralai;
        private Label label5;
        private Label label3;
        private TextBox txtTienKhachDua;
        private Label label4;
        private Label label2;
        private TextBox txtGhiChu;
        private Label label10;
        private RadioButton rdCho;
        private RadioButton rdhuy;
        private RadioButton rddathanhtoan;
        private RadioButton rdchuathanhtoan;
        private Label label9;
        private DateTimePicker dtNgaythanhtoan;
        private Label label8;
        private DateTimePicker dtNgayTao;
        private Label label12;
        private TextBox txtTongTien;
        private Label label11;
        private Button btnThanhToan;
        private TextBox textBox3;
        private Label label13;
        private Label label14;
        private Label label15;
        private Label label16;
        private Label label17;
        private PictureBox pictureBox3;
        private Button button2;
    }
}